touch 1.txt
touch 2.txt
